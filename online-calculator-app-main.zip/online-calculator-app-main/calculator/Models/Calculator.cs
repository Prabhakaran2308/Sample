﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace calculator.Models
{
    public class Calculator
    {
        public Double value1 { get; set; }
        public Double value2 { get; set; }
        public Double Result { get; set; }
        public string calculate { get; set; }

    }
}
